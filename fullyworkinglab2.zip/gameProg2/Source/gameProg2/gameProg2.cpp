// Fill out your copyright notice in the Description page of Project Settings.

#include "gameProg2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, gameProg2, "gameProg2" );
