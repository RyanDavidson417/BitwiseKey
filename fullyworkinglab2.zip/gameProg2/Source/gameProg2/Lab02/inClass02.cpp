// Fill out your copyright notice in the Description page of Project Settings.


#include "inClass02.h"

// Sets default values
AinClass02::AinClass02()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

    
}

// Called when the game starts or when spawned
void AinClass02::BeginPlay()
{
    
	Super::BeginPlay();
	
}

// Called every frame
void AinClass02::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

